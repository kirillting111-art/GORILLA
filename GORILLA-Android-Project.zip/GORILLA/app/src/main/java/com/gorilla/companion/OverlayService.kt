package com.gorilla.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: Button? = null
    private var panel: LinearLayout? = null
    private val channelId = "gorilla_overlay"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("GORILLA запущен")
                .setContentText("Плавающая панель-компаньон активна")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("GORILLA запущен")
                .setContentText("Плавающая панель-компаньон активна")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(7, notification)
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayParams(width: Int, height: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            width, height,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
    }

    private fun showBubble() {
        if (bubble != null) return
        bubble = Button(this).apply {
            text = "G"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(120, 20, 30))
            setOnClickListener { togglePanel() }
        }
        windowManager.addView(bubble, overlayParams(58, 58))
    }

    private fun togglePanel() {
        if (panel != null) {
            try { windowManager.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(28, 28, 32))
        }
        box.addView(TextView(this).apply {
            text = "GORILLA"
            textSize = 20f
            setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = "Профиль: Standoff 2\nПанель-компаньон активна. Настройки прицела и автодействия в матче не изменяются."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 10)
        })
        box.addView(Button(this).apply {
            text = "Скрыть меню"
            setOnClickListener { togglePanel() }
        })
        box.addView(Button(this).apply {
            text = "Закрыть GORILLA"
            setOnClickListener { stopSelf() }
        })
        panel = box
        windowManager.addView(panel, overlayParams(260, WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "GORILLA overlay", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        panel = null
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
