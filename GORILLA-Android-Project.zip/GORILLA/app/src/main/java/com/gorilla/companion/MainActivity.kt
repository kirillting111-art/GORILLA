package com.gorilla.companion

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    // Official Standoff 2 Android package identifier. If the installed edition
    // uses a different package ID, the app reports that it cannot find it.
    private val gamePackage = "com.axlebolt.standoff2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val heading = TextView(this).apply {
            text = "GORILLA"
            textSize = 30f
        }
        val description = TextView(this).apply {
            text = "Плавающая панель-компаньон для Android. Не читает память игры и не управляет прицелом или стрельбой."
            textSize = 16f
            setPadding(0, 18, 0, 24)
        }
        val permission = Button(this).apply {
            text = "Разрешить отображение поверх приложений"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    Toast.makeText(this@MainActivity, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val launch = Button(this).apply {
            text = "Запустить GORILLA и Standoff 2"
            setOnClickListener { startCompanionAndGame() }
        }
        val stop = Button(this).apply {
            text = "Закрыть плавающую панель"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(heading)
        layout.addView(description)
        layout.addView(permission)
        layout.addView(launch)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startCompanionAndGame() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши отображение поверх приложений", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }

        val serviceIntent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
        else startService(serviceIntent)

        val gameIntent = packageManager.getLaunchIntentForPackage(gamePackage)
        if (gameIntent == null) {
            Toast.makeText(this, "Standoff 2 не найден. Проверь установку из Google Play.", Toast.LENGTH_LONG).show()
        } else {
            gameIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(gameIntent)
        }
    }
}
